<?php

/** FOX CODEC IPTVPanel MySQL Databank Connection
 *  www.foxcodec.com
 *  support@foxcodec.com
 */

